
/**
 * Provides classes for communicating via the Noise protocol.
 *
 * Reference: http://noiseprotocol.org
 */
package com.bitchat.android.noise.southernstorm.protocol;
